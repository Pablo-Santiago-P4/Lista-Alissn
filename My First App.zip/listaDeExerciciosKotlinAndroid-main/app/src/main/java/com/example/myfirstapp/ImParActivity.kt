package com.example.myfirstapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView

class ImParActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_im_par)
    }
    fun ImPar(view: View) {
        //ENTRADA
        val editTextNum = findViewById<EditText>(R.id.etNum)
        val num = editTextNum.text.toString().toDouble()


        //PROCESSAMENTO
        if (num % 2 > 0){
            val textView = findViewById<TextView>(R.id.tvResult).apply {
                //text = message
                text = String.format("Esse número é: Ímpar")
            }
           }

        else {
            val textView = findViewById<TextView>(R.id.tvResult).apply {
                //text = message
                text = String.format("Esse número é: Par")
            }
            findViewById<TextView>(R.id.tvMessage).apply {
            //text = message
            text = "RESULTADOS:"
            }
        }
    }
}